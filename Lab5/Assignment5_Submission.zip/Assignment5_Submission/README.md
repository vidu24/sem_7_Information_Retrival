# Intelligent Document Search — Assignment 5

## Install and run

```bash
pip install -r requirements.txt
python main.py
```

Requires Python 3.10+ and an internet connection on first execution to download the pretrained sentence transformer. The command prints evaluation results and then opens an interactive terminal prompt; press Enter to quit. In a notebook or non-interactive environment the prompt ends on EOF.

## Included files
- `main.py`: commented implementation for embedding, K-Means, LDA, PCA, anomaly detection, semantic search and retrieval evaluation.
- `documents.csv`: 25 synthetic demonstration documents from four subjects and one unrelated example.
- `queries.json`: five test queries and relevance judgments.
- `REPORT.md`: short report, evaluation formulas, observations and limitations.
- `requirements.txt`: Python dependencies.
- `outputs/`: generated at runtime, including embeddings, PCA plot, cluster assignments and evaluation results.

## Note
The output artifacts and measured results are generated when the code runs. Screenshots must be captured from that run; none are represented as already executed.
